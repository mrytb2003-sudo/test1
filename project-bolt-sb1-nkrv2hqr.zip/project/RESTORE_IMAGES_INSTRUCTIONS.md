# Restore Original Product Images

## Quick Instructions

1. Go to your Supabase Dashboard: https://djdkujwxkwchboxpqbgz.supabase.co
2. Click **SQL Editor** in the left sidebar
3. Click **New Query**
4. Copy the entire content from `RESTORE_IMAGES.sql` file
5. Paste it into the SQL editor
6. Click **Run** (or press Ctrl+Enter)

## What This Will Do

This SQL script will:

### Set Products (2 products)
- Product 1: image `/1.png` with gallery `[/2.png, /3.png]`
- Product 2: image `/7.png` with gallery `[/8.png, /9.png]`

### Fusta cu volane (3 products)
- Product 1: image `/13.png`
- Product 2: image `/14.png`
- Product 3: image `/15.png`

### Fusta gogosar (3 products)
- Product 1: image `/20 copy.png` - Price: 250 lei
- Product 2: image `/21 copy.png` - Price: 350 lei
- Product 3: image `/22 copy.png` - Price: 250 lei

## Verification

After running the SQL, you should see a result table showing all "Fusta gogosar" products with:
- Correct image paths (`/20 copy.png`, `/21 copy.png`, `/22 copy.png`)
- Correct prices (250, 350, 250)

## Important Notes

- All stock/Pexels images have been removed from the code
- The website now uses ONLY your uploaded product images
- No placeholders or fallback images will be shown
- If an image fails to load, it will show broken instead of a stock photo
