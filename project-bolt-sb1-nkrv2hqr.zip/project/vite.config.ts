import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { copyFileSync, readdirSync, statSync, mkdirSync } from 'fs';
import { join } from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  base: '/',
  plugins: [
    react(),
    {
      name: 'copy-public-files',
      closeBundle() {
        const publicDir = 'public';
        const outDir = 'dist';

        try {
          const files = readdirSync(publicDir);
          files.forEach(file => {
            // Skip files with spaces in name
            if (file.includes(' ')) return;

            try {
              const srcPath = join(publicDir, file);
              const destPath = join(outDir, file);
              const stat = statSync(srcPath);

              if (stat.isFile()) {
                copyFileSync(srcPath, destPath);
              }
            } catch (err) {
              // Skip files that can't be accessed
            }
          });
        } catch (err) {
          console.error('Error copying public files:', err);
        }
      }
    }
  ],
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  build: {
    copyPublicDir: false,
    assetsInlineLimit: 0
  }
});
