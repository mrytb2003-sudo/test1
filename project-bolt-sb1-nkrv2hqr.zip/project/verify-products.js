import { createClient } from '@supabase/supabase-js';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync } from 'fs';

// Load environment variables
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const envPath = join(__dirname, '.env');
const envConfig = readFileSync(envPath, 'utf-8');
const envVars = {};
envConfig.split('\n').forEach(line => {
  const [key, ...valueParts] = line.split('=');
  if (key && valueParts.length) {
    envVars[key.trim()] = valueParts.join('=').trim();
  }
});

const supabaseUrl = envVars.VITE_SUPABASE_URL;
const supabaseAnonKey = envVars.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase credentials');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function verifyProducts() {
  console.log('Fetching current product data...\n');

  const { data: products, error } = await supabase
    .from('products')
    .select('id, name, image_url, images')
    .in('name', ['Set', 'Fusta cu volane', 'Fusta gogosar'])
    .order('name', { ascending: true });

  if (error) {
    console.error('Error fetching products:', error.message);
    process.exit(1);
  }

  console.log('Current products in database:');
  products.forEach(p => {
    console.log(`\nID: ${p.id}`);
    console.log(`Name: ${p.name}`);
    console.log(`Image URL: ${p.image_url}`);
    console.log(`Images: ${JSON.stringify(p.images)}`);
  });
}

verifyProducts().catch(console.error);
