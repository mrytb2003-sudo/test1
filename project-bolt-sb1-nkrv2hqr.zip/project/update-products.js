import { createClient } from '@supabase/supabase-js';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync } from 'fs';

// Load environment variables
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const envPath = join(__dirname, '.env');
const envConfig = readFileSync(envPath, 'utf-8');
const envVars = {};
envConfig.split('\n').forEach(line => {
  const [key, ...valueParts] = line.split('=');
  if (key && valueParts.length) {
    envVars[key.trim()] = valueParts.join('=').trim();
  }
});

const supabaseUrl = envVars.VITE_SUPABASE_URL;
const supabaseAnonKey = envVars.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase credentials');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function updateProducts() {
  console.log('Starting product image update...\n');

  // Execute the UPDATE query
  const updateQuery = `
    UPDATE products
    SET
      image_url = CASE
        WHEN name = 'Set' AND id = 'd696dcd9-0b43-40f4-96bb-42d9008ac37c' THEN '/1.png'
        WHEN name = 'Set' AND id = '45950842-5162-4f9e-9357-a59630ed75ff' THEN '/7.png'
        WHEN name = 'Fusta cu volane' AND id = 'bffd52ef-5f75-4051-b7a5-e049bc6d87f4' THEN '/13.png'
        WHEN name = 'Fusta cu volane' AND id = '4f9c594b-c2f6-41ab-9649-1344acdb9f27' THEN '/14.png'
        WHEN name = 'Fusta cu volane' AND id = '13beeab8-6568-4d97-8b4f-731e99fcc697' THEN '/15.png'
        WHEN name = 'Fusta gogosar' AND id = '095fb861-a243-4624-ad18-e5f3a0696ab7' THEN '/20.png'
        WHEN name = 'Fusta gogosar' AND id = '985862d4-465f-46b3-9506-9d8ea8d59639' THEN '/21.png'
        WHEN name = 'Fusta gogosar' AND id = 'a7b1b886-6704-4a42-9b44-ca7eade118cf' THEN '/22.png'
        ELSE image_url
      END,
      images = CASE
        WHEN name = 'Set' AND id = 'd696dcd9-0b43-40f4-96bb-42d9008ac37c' THEN '["/2.png", "/3.png"]'::jsonb
        WHEN name = 'Set' AND id = '45950842-5162-4f9e-9357-a59630ed75ff' THEN '["/8.png", "/9.png"]'::jsonb
        ELSE '[]'::jsonb
      END
    WHERE name IN ('Set', 'Fusta cu volane', 'Fusta gogosar')
  `;

  const { data: updateData, error: updateError } = await supabase.rpc('exec_sql', {
    query: updateQuery
  });

  // Since rpc might not be available, let's use direct updates instead
  // We'll update each product individually

  const updates = [
    { id: 'd696dcd9-0b43-40f4-96bb-42d9008ac37c', image_url: '/1.png', images: ['/2.png', '/3.png'] },
    { id: '45950842-5162-4f9e-9357-a59630ed75ff', image_url: '/7.png', images: ['/8.png', '/9.png'] },
    { id: 'bffd52ef-5f75-4051-b7a5-e049bc6d87f4', image_url: '/13.png', images: [] },
    { id: '4f9c594b-c2f6-41ab-9649-1344acdb9f27', image_url: '/14.png', images: [] },
    { id: '13beeab8-6568-4d97-8b4f-731e99fcc697', image_url: '/15.png', images: [] },
    { id: '095fb861-a243-4624-ad18-e5f3a0696ab7', image_url: '/20.png', images: [] },
    { id: '985862d4-465f-46b3-9506-9d8ea8d59639', image_url: '/21.png', images: [] },
    { id: 'a7b1b886-6704-4a42-9b44-ca7eade118cf', image_url: '/22.png', images: [] }
  ];

  console.log('Updating products...\n');

  for (const update of updates) {
    const { data, error } = await supabase
      .from('products')
      .update({
        image_url: update.image_url,
        images: update.images
      })
      .eq('id', update.id)
      .select();

    if (error) {
      console.error(`Error updating product ${update.id}:`, error.message);
    } else {
      console.log(`✓ Updated product ${update.id}: image_url="${update.image_url}", images=${JSON.stringify(update.images)}`);
    }
  }

  console.log('\n--- Verification: Fetching all updated products ---\n');

  // Verify the changes
  const { data: products, error: selectError } = await supabase
    .from('products')
    .select('id, name, image_url, images')
    .in('name', ['Set', 'Fusta cu volane', 'Fusta gogosar'])
    .order('name', { ascending: true });

  if (selectError) {
    console.error('Error fetching products:', selectError.message);
    process.exit(1);
  }

  console.log('Updated products:');
  console.table(products.map(p => ({
    id: p.id,
    name: p.name,
    image_url: p.image_url,
    images: JSON.stringify(p.images)
  })));

  console.log('\n✓ Product images have been successfully updated!');
}

updateProducts().catch(console.error);
