import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://djdkujwxkwchboxpqbgz.supabase.co';
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function restoreImages() {
  console.log('Restoring original product images...');

  const updates = [
    { id: 'd696dcd9-0b43-40f4-96bb-42d9008ac37c', image_url: '/1.png', images: ['/2.png', '/3.png'] },
    { id: '45950842-5162-4f9e-9357-a59630ed75ff', image_url: '/7.png', images: ['/8.png', '/9.png'] },
    { id: 'bffd52ef-5f75-4051-b7a5-e049bc6d87f4', image_url: '/13.png', images: [] },
    { id: '4f9c594b-c2f6-41ab-9649-1344acdb9f27', image_url: '/14.png', images: [] },
    { id: '13beeab8-6568-4d97-8b4f-731e99fcc697', image_url: '/15.png', images: [] },
    { id: '095fb861-a243-4624-ad18-e5f3a0696ab7', image_url: '/20.png', images: [] },
    { id: '985862d4-465f-46b3-9506-9d8ea8d59639', image_url: '/21.png', images: [] },
    { id: 'a7b1b886-6704-4a42-9b44-ca7eade118cf', image_url: '/22.png', images: [] },
  ];

  for (const update of updates) {
    const { error } = await supabase
      .from('products')
      .update({ image_url: update.image_url, images: update.images })
      .eq('id', update.id);

    if (error) {
      console.error(`Error updating product ${update.id}:`, error);
    } else {
      console.log(`✓ Updated product ${update.id} with ${update.image_url}`);
    }
  }

  console.log('\nVerifying updates...');
  const { data, error } = await supabase
    .from('products')
    .select('id, name, image_url, images')
    .order('name');

  if (error) {
    console.error('Error fetching products:', error);
  } else {
    console.table(data);
  }
}

restoreImages().catch(console.error);
