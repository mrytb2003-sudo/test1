export function getImageUrl(path: string | null | undefined): string {
  if (!path) return '';

  // Return the path as-is since all paths in the database already start with /
  return path;
}
