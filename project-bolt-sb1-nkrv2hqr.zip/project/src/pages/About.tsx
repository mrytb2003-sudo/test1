import { Heart, Sparkles, Users } from 'lucide-react';

export function About() {
  return (
    <div className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-16">
          <h1 className="text-4xl font-light tracking-tight mb-4">Povestea Noastră</h1>
          <p className="text-gray-600">Unde eleganța întâlnește simplitatea</p>
        </div>

        <div className="prose prose-lg max-w-none space-y-8 text-gray-700">
          <p className="text-xl font-light leading-relaxed">
            Karelli s-a născut din dorința de a crea îmbrăcăminte atemporală pentru femeia modernă care apreciază simplitatea, calitatea și eleganța discretă.
          </p>

          <p>
            În 2020, am început această călătorie cu o viziune clară: să oferim piese vestimentare care transcend tendințele trecătoare și devin elemente de bază în garderoba fiecărei femei. Fiecare produs este selectat cu grijă pentru a reflecta valorile noastre fundamentale de simplitate, calitate și sustenabilitate.
          </p>

          <div className="grid md:grid-cols-3 gap-8 my-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-light mb-2">Pasiune</h3>
              <p className="text-sm text-gray-600">Pentru modă atemporală și design minimalist</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-light mb-2">Calitate</h3>
              <p className="text-sm text-gray-600">Materiale premium și atenție la detalii</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-light mb-2">Comunitate</h3>
              <p className="text-sm text-gray-600">O familie de femei care apreciază eleganța</p>
            </div>
          </div>

          <h2 className="text-2xl font-light mt-12 mb-4">Filosofia Noastră</h2>
          <p>
            Credem că adevărata eleganță provine din simplitate. Nu este nevoie de complicații pentru a arăta și a te simți bine. Piesele noastre sunt concepute pentru a se integra perfect în stilul de viață al femeii moderne - versatile, confortabile și mereu elegante.
          </p>

          <p>
            Fiecare articol din colecția Karelli este ales pentru a rezista testului timpului, atât în ceea ce privește calitatea, cât și stilul. Dorim să creăm îmbrăcăminte pe care să o porți ani de zile, nu doar un sezon.
          </p>

          <h2 className="text-2xl font-light mt-12 mb-4">Angajamentul Nostru</h2>
          <p>
            Ne angajăm să oferim nu doar produse de calitate superioară, ci și o experiență de cumpărare excepțională. De la momentul în care descoperi colecția noastră până când primești și despachetezi comanda ta, dorim ca fiecare pas să fie o plăcere.
          </p>

          <p>
            Suntem dedicate practicilor etice și durabile în tot ceea ce facem. Lucrăm constant pentru a reduce impactul nostru asupra mediului și pentru a ne asigura că partenerii noștri împărtășesc aceleași valori.
          </p>
        </div>

        <div className="mt-16 bg-stone-50 p-12 rounded-lg text-center">
          <h2 className="text-2xl font-light mb-4">Alătură-te Comunității Karelli</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Fii parte din familia noastră și descoperă o lume a eleganței fără efort. Înscrie-te pentru a primi inspirație, oferte exclusive și să fii prima care află despre noile colecții.
          </p>
          <div className="flex justify-center gap-4">
            <input
              type="email"
              placeholder="Email-ul tău"
              className="px-6 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-black w-80"
            />
            <button className="bg-black text-white px-8 py-3 rounded-lg hover:bg-gray-800 transition-colors">
              Abonează-te
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
