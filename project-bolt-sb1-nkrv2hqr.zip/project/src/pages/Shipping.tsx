import { Package, Truck, Clock } from 'lucide-react';

export function Shipping() {
  return (
    <div className="py-16 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
      <div className="mb-12">
        <h1 className="text-4xl font-light tracking-tight mb-4">Informații Livrare</h1>
        <p className="text-gray-600">Detalii despre livrarea comenzilor tale</p>
      </div>

      <div className="space-y-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Truck className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-light mb-2">Livrare Rapidă</h3>
            <p className="text-sm text-gray-600">2-3 zile lucrătoare în toată țara</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Package className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-light mb-2">Livrare Gratuită</h3>
            <p className="text-sm text-gray-600">Pentru comenzi peste 300 RON</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-light mb-2">Procesare Rapidă</h3>
            <p className="text-sm text-gray-600">Comenzile se procesează în 24h</p>
          </div>
        </div>

        <div className="prose prose-sm max-w-none">
          <h2 className="text-2xl font-light mb-4">Costuri de Livrare</h2>
          <div className="bg-stone-50 p-6 rounded-lg space-y-3">
            <div className="flex justify-between items-center">
              <span>Livrare standard (2-3 zile lucrătoare)</span>
              <span className="font-medium">25 RON</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Livrare express (1 zi lucrătoare)</span>
              <span className="font-medium">45 RON</span>
            </div>
            <div className="flex justify-between items-center border-t border-gray-200 pt-3">
              <span className="font-medium">Comenzi peste 300 RON</span>
              <span className="font-medium text-green-600">GRATUIT</span>
            </div>
          </div>

          <h2 className="text-2xl font-light mb-4 mt-8">Metode de Livrare</h2>
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-light mb-2">Curier la Domiciliu</h3>
              <p className="text-gray-600">Livrăm prin curier partener Fan Courier în toată România. Vei primi un SMS cu numărul de tracking după expedierea comenzii.</p>
            </div>
            <div>
              <h3 className="text-lg font-light mb-2">Ridicare de la Easybox</h3>
              <p className="text-gray-600">Poți alege să ridici coletul de la un punct Easybox din apropierea ta, disponibil 24/7.</p>
            </div>
          </div>

          <h2 className="text-2xl font-light mb-4 mt-8">Termene de Livrare</h2>
          <div className="space-y-3 text-gray-600">
            <p>Comenzile plasate Luni-Vineri până la ora 14:00 sunt procesate și expediate în aceeași zi.</p>
            <p>Comenzile plasate după ora 14:00 sau în weekend sunt procesate în următoarea zi lucrătoare.</p>
            <p>Termenele de livrare sunt estimate și pot varia în funcție de destinație și perioada anului.</p>
          </div>

          <h2 className="text-2xl font-light mb-4 mt-8">Urmărire Comandă</h2>
          <p className="text-gray-600">După expedierea comenzii, vei primi un email cu numărul AWB și link pentru urmărirea coletului în timp real.</p>
        </div>
      </div>
    </div>
  );
}
