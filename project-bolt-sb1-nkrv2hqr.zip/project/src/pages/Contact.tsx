import { Mail, Phone, MapPin } from 'lucide-react';

export function Contact() {
  return (
    <div className="py-16 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
      <div className="mb-12">
        <h1 className="text-4xl font-light tracking-tight mb-4">Contactează-ne</h1>
        <p className="text-gray-600">Suntem aici să te ajutăm. Trimite-ne un mesaj și îți vom răspunde în curând.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-12">
        <div>
          <form className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-light mb-2">Nume</label>
              <input
                type="text"
                id="name"
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-black"
                placeholder="Numele tău"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-light mb-2">Email</label>
              <input
                type="email"
                id="email"
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-black"
                placeholder="email@exemplu.ro"
              />
            </div>
            <div>
              <label htmlFor="subject" className="block text-sm font-light mb-2">Subiect</label>
              <input
                type="text"
                id="subject"
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-black"
                placeholder="Cum te putem ajuta?"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-light mb-2">Mesaj</label>
              <textarea
                id="message"
                rows={6}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-black"
                placeholder="Scrie mesajul tău aici..."
              />
            </div>
            <button
              type="submit"
              className="w-full bg-black text-white py-3 px-6 rounded-lg hover:bg-gray-800 transition-colors"
            >
              Trimite Mesaj
            </button>
          </form>
        </div>

        <div className="space-y-8">
          <div>
            <h3 className="text-lg font-light mb-6">Informații de Contact</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Mail className="w-5 h-5 mt-1 text-gray-600" />
                <div>
                  <p className="text-sm font-light mb-1">Email</p>
                  <a href="mailto:contact@karelli.ro" className="text-gray-600 hover:text-black transition-colors">
                    contact@karelli.ro
                  </a>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Phone className="w-5 h-5 mt-1 text-gray-600" />
                <div>
                  <p className="text-sm font-light mb-1">Telefon</p>
                  <a href="tel:+40123456789" className="text-gray-600 hover:text-black transition-colors">
                    +40 123 456 789
                  </a>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 mt-1 text-gray-600" />
                <div>
                  <p className="text-sm font-light mb-1">Adresă</p>
                  <p className="text-gray-600">
                    Strada Exemplu 123<br />
                    București, România
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-gray-200">
            <h3 className="text-lg font-light mb-4">Program de Lucru</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <p>Luni - Vineri: 09:00 - 18:00</p>
              <p>Sâmbătă: 10:00 - 16:00</p>
              <p>Duminică: Închis</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
