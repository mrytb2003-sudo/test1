import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface FAQItemProps {
  question: string;
  answer: string;
}

function FAQItem({ question, answer }: FAQItemProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-gray-200">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-6 flex items-center justify-between text-left hover:text-gray-600 transition-colors"
      >
        <span className="font-light text-lg pr-8">{question}</span>
        <ChevronDown
          className={`w-5 h-5 flex-shrink-0 transition-transform ${
            isOpen ? 'transform rotate-180' : ''
          }`}
        />
      </button>
      {isOpen && (
        <div className="pb-6 text-gray-600 leading-relaxed">
          {answer}
        </div>
      )}
    </div>
  );
}

export function FAQ() {
  const faqs = [
    {
      question: 'Cum pot plasa o comandă?',
      answer: 'Poți plasa o comandă direct pe website-ul nostru. Adaugă produsele dorite în coș, completează datele de livrare și alege metoda de plată preferată. Vei primi o confirmare prin email imediat după plasarea comenzii.'
    },
    {
      question: 'Ce metode de plată acceptați?',
      answer: 'Acceptăm plata cu cardul (Visa, Mastercard, American Express) și ramburs la curier. Toate plățile cu cardul sunt procesate securizat printr-un gateway de plată certificat.'
    },
    {
      question: 'Cât durează livrarea?',
      answer: 'Livrarea standard durează 2-3 zile lucrătoare, iar livrarea express 1 zi lucrătoare. Comenzile plasate înainte de ora 14:00 sunt expediate în aceeași zi. Pentru comenzi peste 300 RON, livrarea este gratuită.'
    },
    {
      question: 'Cum pot returna un produs?',
      answer: 'Ai 30 de zile de la primirea comenzii pentru a returna produsele. Contactează-ne la retururi@karelli.ro pentru a primi o etichetă de retur gratuită. Produsele trebuie să fie nepurtate, cu etichetele atașate și în ambalajul original.'
    },
    {
      question: 'Pot schimba un produs cu altă mărime sau culoare?',
      answer: 'Da, poți returna produsul inițial și să plasezi o comandă nouă pentru mărimea sau culoarea dorită. Acest proces ne permite să procesăm cererea ta mai rapid. Consultă politica de returnare pentru mai multe detalii.'
    },
    {
      question: 'Cum știu ce mărime să aleg?',
      answer: 'Consultă ghidul nostru de mărimi pentru măsurători detaliate. Fiecare produs are dimensiuni specifice în descriere. Dacă te afli între două mărimi, recomandăm să alegi mărimea mai mare. Pentru asistență personalizată, nu ezita să ne contactezi.'
    },
    {
      question: 'Produsele sunt disponibile în stoc?',
      answer: 'Produsele afișate pe website sunt în stoc și disponibile pentru comandă. În cazul în care un produs nu mai este disponibil după plasarea comenzii, te vom contacta imediat pentru a discuta alternativele.'
    },
    {
      question: 'Pot anula o comandă după ce am plasat-o?',
      answer: 'Poți anula comanda înainte de expedierea acesteia. Contactează-ne cât mai repede la contact@karelli.ro sau +40 123 456 789. Dacă comanda a fost deja expediată, va trebui să urmezi procesul standard de returnare.'
    },
    {
      question: 'Oferiți carduri cadou?',
      answer: 'Da, oferim carduri cadou în diferite valori. Cardurile cadou sunt valabile 12 luni de la data achiziției și pot fi folosite pentru orice produs din colecția noastră. Contactează-ne pentru mai multe detalii.'
    },
    {
      question: 'Cum pot urmări comanda mea?',
      answer: 'După expedierea comenzii, vei primi un email cu numărul AWB și link pentru urmărirea coletului în timp real. Poți verifica statusul comenzii și în contul tău, dacă ai creat unul la plasarea comenzii.'
    },
    {
      question: 'Aveți magazin fizic?',
      answer: 'Momentan activitatea noastră este exclusiv online, ceea ce ne permite să oferim prețuri competitive și o experiență de cumpărare convenabilă de acasă. Totuși, lucrăm la deschiderea unui showroom în București.'
    },
    {
      question: 'Cum pot afla despre noutăți și promoții?',
      answer: 'Abonează-te la newsletter-ul nostru pentru a primi informații despre colecțiile noi, oferte exclusive și sfaturi de styling. De asemenea, urmărește-ne pe social media pentru inspirație zilnică și anunțuri speciale.'
    }
  ];

  return (
    <div className="py-16 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
      <div className="mb-12">
        <h1 className="text-4xl font-light tracking-tight mb-4">Întrebări Frecvente</h1>
        <p className="text-gray-600">Găsește răspunsuri la întrebările tale despre Karelli</p>
      </div>

      <div className="space-y-1">
        {faqs.map((faq, index) => (
          <FAQItem key={index} question={faq.question} answer={faq.answer} />
        ))}
      </div>

      <div className="mt-12 bg-stone-50 p-8 rounded-lg text-center">
        <h3 className="text-xl font-light mb-3">Nu ai găsit răspunsul tău?</h3>
        <p className="text-gray-600 mb-6">Echipa noastră este bucuroasă să te ajute cu orice întrebare.</p>
        <a
          href="/contact"
          className="inline-block bg-black text-white px-8 py-3 rounded-lg hover:bg-gray-800 transition-colors"
        >
          Contactează-ne
        </a>
      </div>
    </div>
  );
}
