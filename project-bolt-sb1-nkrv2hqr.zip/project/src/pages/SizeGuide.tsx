import { Ruler } from 'lucide-react';

export function SizeGuide() {
  return (
    <div className="py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
      <div className="mb-12">
        <h1 className="text-4xl font-light tracking-tight mb-4">Ghid Mărimi</h1>
        <p className="text-gray-600">Găsește mărimea perfectă pentru tine</p>
      </div>

      <div className="space-y-12">
        <div className="bg-stone-50 p-8 rounded-lg">
          <Ruler className="w-12 h-12 mb-4" />
          <h2 className="text-xl font-light mb-4">Cum să iei măsurătorile</h2>
          <div className="grid md:grid-cols-2 gap-6 text-sm text-gray-600">
            <div>
              <h3 className="font-medium text-black mb-2">1. Bust</h3>
              <p>Măsoară în jurul părții celei mai pline a bustului, menținând centimetrul paralel cu solul.</p>
            </div>
            <div>
              <h3 className="font-medium text-black mb-2">2. Talie</h3>
              <p>Măsoară în jurul părții celei mai înguste a taliei, de obicei deasupra buricului.</p>
            </div>
            <div>
              <h3 className="font-medium text-black mb-2">3. Șolduri</h3>
              <p>Măsoară în jurul părții celei mai pline a șoldurilor, ținând centimetrul paralel cu solul.</p>
            </div>
            <div>
              <h3 className="font-medium text-black mb-2">4. Lungime Îmbrăcăminte</h3>
              <p>Măsoară de la punctul cel mai înalt al umărului până la lungimea dorită.</p>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-light mb-6">Tabel Mărimi - Îmbrăcăminte</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-stone-50">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Mărime</th>
                  <th className="px-4 py-3 text-left font-medium">Bust (cm)</th>
                  <th className="px-4 py-3 text-left font-medium">Talie (cm)</th>
                  <th className="px-4 py-3 text-left font-medium">Șolduri (cm)</th>
                  <th className="px-4 py-3 text-left font-medium">Mărime EU</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="px-4 py-3 font-medium">XS</td>
                  <td className="px-4 py-3 text-gray-600">80-84</td>
                  <td className="px-4 py-3 text-gray-600">60-64</td>
                  <td className="px-4 py-3 text-gray-600">86-90</td>
                  <td className="px-4 py-3 text-gray-600">34</td>
                </tr>
                <tr className="bg-stone-50">
                  <td className="px-4 py-3 font-medium">S</td>
                  <td className="px-4 py-3 text-gray-600">84-88</td>
                  <td className="px-4 py-3 text-gray-600">64-68</td>
                  <td className="px-4 py-3 text-gray-600">90-94</td>
                  <td className="px-4 py-3 text-gray-600">36</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-medium">M</td>
                  <td className="px-4 py-3 text-gray-600">88-92</td>
                  <td className="px-4 py-3 text-gray-600">68-72</td>
                  <td className="px-4 py-3 text-gray-600">94-98</td>
                  <td className="px-4 py-3 text-gray-600">38</td>
                </tr>
                <tr className="bg-stone-50">
                  <td className="px-4 py-3 font-medium">L</td>
                  <td className="px-4 py-3 text-gray-600">92-96</td>
                  <td className="px-4 py-3 text-gray-600">72-76</td>
                  <td className="px-4 py-3 text-gray-600">98-102</td>
                  <td className="px-4 py-3 text-gray-600">40</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-medium">XL</td>
                  <td className="px-4 py-3 text-gray-600">96-100</td>
                  <td className="px-4 py-3 text-gray-600">76-80</td>
                  <td className="px-4 py-3 text-gray-600">102-106</td>
                  <td className="px-4 py-3 text-gray-600">42</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-light mb-6">Pantofi și Accesorii</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-light mb-4">Mărime Pantofi</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-stone-50">
                    <tr>
                      <th className="px-4 py-3 text-left font-medium">EU</th>
                      <th className="px-4 py-3 text-left font-medium">UK</th>
                      <th className="px-4 py-3 text-left font-medium">cm</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="px-4 py-3">36</td>
                      <td className="px-4 py-3 text-gray-600">3.5</td>
                      <td className="px-4 py-3 text-gray-600">23</td>
                    </tr>
                    <tr className="bg-stone-50">
                      <td className="px-4 py-3">37</td>
                      <td className="px-4 py-3 text-gray-600">4</td>
                      <td className="px-4 py-3 text-gray-600">23.5</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-3">38</td>
                      <td className="px-4 py-3 text-gray-600">5</td>
                      <td className="px-4 py-3 text-gray-600">24</td>
                    </tr>
                    <tr className="bg-stone-50">
                      <td className="px-4 py-3">39</td>
                      <td className="px-4 py-3 text-gray-600">6</td>
                      <td className="px-4 py-3 text-gray-600">25</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-3">40</td>
                      <td className="px-4 py-3 text-gray-600">6.5</td>
                      <td className="px-4 py-3 text-gray-600">25.5</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-light mb-3">Genți</h3>
                <div className="text-sm text-gray-600 space-y-2">
                  <p><strong className="text-black">Mini:</strong> 15-20 cm</p>
                  <p><strong className="text-black">Mică:</strong> 20-30 cm</p>
                  <p><strong className="text-black">Medie:</strong> 30-40 cm</p>
                  <p><strong className="text-black">Mare:</strong> 40+ cm</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-amber-50 border border-amber-200 p-6 rounded-lg">
          <h3 className="font-medium mb-2">Sfat Util</h3>
          <p className="text-sm text-gray-700">
            Dacă te afli între două mărimi, recomandăm să alegi mărimea mai mare pentru un confort optim. Fiecare produs are dimensiuni specifice în descriere pentru a te ajuta să faci alegerea perfectă.
          </p>
        </div>

        <div className="text-center pt-8 border-t border-gray-200">
          <h3 className="text-lg font-light mb-2">Ai nevoie de ajutor?</h3>
          <p className="text-gray-600 mb-4">Echipa noastră este aici să te ajute să găsești mărimea perfectă.</p>
          <a
            href="/contact"
            className="inline-block bg-black text-white px-8 py-3 rounded-lg hover:bg-gray-800 transition-colors"
          >
            Contactează-ne
          </a>
        </div>
      </div>
    </div>
  );
}
