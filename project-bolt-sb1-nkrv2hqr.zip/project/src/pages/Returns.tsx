import { RotateCcw, CheckCircle, XCircle } from 'lucide-react';

export function Returns() {
  return (
    <div className="py-16 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
      <div className="mb-12">
        <h1 className="text-4xl font-light tracking-tight mb-4">Politica de Returnare</h1>
        <p className="text-gray-600">Dorința ta de mulțumire este prioritatea noastră</p>
      </div>

      <div className="space-y-12">
        <div className="bg-stone-50 p-8 rounded-lg text-center">
          <RotateCcw className="w-12 h-12 mx-auto mb-4" />
          <h2 className="text-2xl font-light mb-2">30 de Zile Retur Gratuit</h2>
          <p className="text-gray-600">Ai la dispoziție 30 de zile de la primirea produsului pentru a returna articolele care nu îți plac.</p>
        </div>

        <div className="prose prose-sm max-w-none">
          <h2 className="text-2xl font-light mb-4">Cum Funcționează Returul?</h2>
          <ol className="space-y-4 text-gray-600">
            <li>
              <strong className="text-black">Contactează-ne</strong>
              <br />
              Trimite un email la <a href="mailto:retururi@karelli.ro" className="text-black hover:underline">retururi@karelli.ro</a> sau sună la <a href="tel:+40123456789" className="text-black hover:underline">+40 123 456 789</a> pentru a anunța returnarea.
            </li>
            <li>
              <strong className="text-black">Pregătește Produsele</strong>
              <br />
              Ambalează produsele în ambalajul original, împreună cu toate etichetele și accesoriile primite.
            </li>
            <li>
              <strong className="text-black">Expediază Coletul</strong>
              <br />
              Vei primi o etichetă de retur gratuită pe care să o aplici pe colet. Curierul va ridica coletul de la adresa ta.
            </li>
            <li>
              <strong className="text-black">Primește Rambursarea</strong>
              <br />
              După ce primim și verificăm produsele, îți vom returna banii în maxim 7 zile lucrătoare.
            </li>
          </ol>

          <h2 className="text-2xl font-light mb-4 mt-8">Condiții de Returnare</h2>

          <div className="space-y-6">
            <div>
              <div className="flex items-start space-x-3 mb-3">
                <CheckCircle className="w-5 h-5 mt-0.5 text-green-600 flex-shrink-0" />
                <div>
                  <h3 className="font-medium text-black mb-1">Produse Acceptate pentru Retur</h3>
                  <ul className="text-gray-600 space-y-1">
                    <li>Produse nepurtate și nefolosite</li>
                    <li>Cu toate etichetele originale atașate</li>
                    <li>În ambalajul original, nedeteriorate</li>
                    <li>Fără urme de parfum, machiaj sau pete</li>
                  </ul>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-start space-x-3">
                <XCircle className="w-5 h-5 mt-0.5 text-red-600 flex-shrink-0" />
                <div>
                  <h3 className="font-medium text-black mb-1">Produse Care NU Pot Fi Returnate</h3>
                  <ul className="text-gray-600 space-y-1">
                    <li>Lenjerie intimă și costume de baie</li>
                    <li>Produse personalizate sau la comandă</li>
                    <li>Produse marcate ca "vânzare finală"</li>
                    <li>Produse deteriorate sau modificate</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <h2 className="text-2xl font-light mb-4 mt-8">Schimburi de Produse</h2>
          <p className="text-gray-600">
            Dacă dorești să schimbi un produs cu altă mărime sau culoare, te rugăm să returnezi articolul inițial și să plasezi o comandă nouă pentru produsul dorit. Acest proces ne permite să procesăm cererea ta mai rapid.
          </p>

          <h2 className="text-2xl font-light mb-4 mt-8">Metode de Rambursare</h2>
          <div className="bg-stone-50 p-6 rounded-lg space-y-2 text-gray-600">
            <p>Rambursarea se va face prin aceeași metodă de plată folosită la comandă:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Plată cu cardul: rambursare pe card în 5-7 zile lucrătoare</li>
              <li>Ramburs: transfer bancar în contul specificat</li>
            </ul>
          </div>

          <h2 className="text-2xl font-light mb-4 mt-8">Întrebări?</h2>
          <p className="text-gray-600">
            Dacă ai nelămuriri despre procesul de returnare, nu ezita să ne contactezi la <a href="mailto:contact@karelli.ro" className="text-black hover:underline">contact@karelli.ro</a> sau la <a href="tel:+40123456789" className="text-black hover:underline">+40 123 456 789</a>.
          </p>
        </div>
      </div>
    </div>
  );
}
