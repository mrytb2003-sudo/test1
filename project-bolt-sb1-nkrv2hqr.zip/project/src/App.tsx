import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { Header } from './components/Header';
import { Cart } from './components/Cart';
import { SizeGuideModal } from './components/SizeGuideModal';
import { Home } from './pages/Home';
import { Category } from './pages/Category';
import { Contact } from './pages/Contact';
import { Shipping } from './pages/Shipping';
import { Returns } from './pages/Returns';
import { SizeGuide } from './pages/SizeGuide';
import { FAQ } from './pages/FAQ';
import { About } from './pages/About';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <Header onCartClick={() => setIsCartOpen(true)} />

      <main className="pt-20">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/categorie/:category" element={<Category />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/livrare" element={<Shipping />} />
          <Route path="/retururi" element={<Returns />} />
          <Route path="/ghid-marimi" element={<SizeGuide />} />
          <Route path="/intrebari-frecvente" element={<FAQ />} />
          <Route path="/despre" element={<About />} />
        </Routes>
      </main>

      <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      <SizeGuideModal isOpen={isSizeGuideOpen} onClose={() => setIsSizeGuideOpen(false)} />

      <footer className="bg-stone-50 border-t border-gray-100 py-16 px-4">
        <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-20">
          <div className="text-center md:text-left">
            <Link to="/" className="text-lg tracking-wider font-light mb-4 block hover:text-gray-600 transition-colors">
              KARELLI
            </Link>
            <p className="text-sm text-gray-600 leading-relaxed">
              Eleganță atemporală pentru femeia modernă
            </p>
          </div>
          <div className="text-center md:text-left">
            <h4 className="text-sm tracking-wide mb-4">Social</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <a
                  href="https://instagram.com/karelliclothing"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-black hover:underline transition-all"
                >
                  Instagram: karelliclothing
                </a>
              </li>
              <li>
                <a
                  href="https://tiktok.com/@karinaluncasu"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-black hover:underline transition-all"
                >
                  TikTok: karinaluncasu
                </a>
              </li>
              <li>
                <button
                  onClick={() => setIsSizeGuideOpen(true)}
                  className="hover:text-black hover:underline transition-all"
                >
                  Ghid de mărimi
                </button>
              </li>
            </ul>
          </div>
        </div>
        <div className="max-w-4xl mx-auto mt-12 pt-8 border-t border-gray-200 text-center text-sm text-gray-500">
          <p>&copy; 2024 Karelli. Toate drepturile rezervate.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
