import { X } from 'lucide-react';
import { useState } from 'react';
import type { Product } from '../types/database';
import { useCart } from '../context/CartContext';
import { getImageUrl } from '../utils/imageUtils';

interface ProductDetailProps {
  product: Product;
  onClose: () => void;
}

export function ProductDetail({ product, onClose }: ProductDetailProps) {
  const { addItem } = useCart();
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const sizes = Array.isArray(product.sizes) ? product.sizes : [];

  const allImages = [product.image_url, ...(Array.isArray(product.images) ? product.images : [])].map(getImageUrl);


  const handleAddToCart = () => {
    addItem(product, selectedSize);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
      <div className="bg-white max-w-5xl w-full max-h-[90vh] overflow-y-auto rounded-sm">
        <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex justify-between items-center">
          <h2 className="text-lg font-light tracking-wide">Detalii Produs</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-8 p-6">
          <div className="space-y-4">
            <div className="aspect-[3/4] bg-gray-100 overflow-hidden">
              <img
                src={allImages[currentImageIndex]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            {allImages.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {allImages.map((img, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`flex-shrink-0 w-20 h-24 bg-gray-100 overflow-hidden border-2 transition-all ${
                      currentImageIndex === index
                        ? 'border-black'
                        : 'border-transparent hover:border-gray-300'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-light tracking-tight mb-2">{product.name}</h1>
              <p className="text-2xl text-gray-900">{Math.round(product.price)} lei</p>
            </div>

            <p className="text-gray-600 leading-relaxed">{product.description}</p>

            {sizes.length > 0 && (
              <div>
                <label className="block text-sm tracking-wide mb-3">Selectează Mărimea</label>
                <div className="flex flex-wrap gap-2">
                  {sizes.map((size: string) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-6 py-2 text-sm tracking-wide border transition-all ${
                        selectedSize === size
                          ? 'bg-black text-white border-black'
                          : 'bg-white text-black border-gray-300 hover:border-black'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={handleAddToCart}
              disabled={!product.in_stock}
              className={`w-full py-4 text-sm tracking-wider transition-all ${
                product.in_stock
                  ? 'bg-black text-white hover:bg-gray-800'
                  : 'bg-gray-200 text-gray-500 cursor-not-allowed'
              }`}
            >
              {product.in_stock ? 'ADAUGĂ ÎN COȘ' : 'STOC EPUIZAT'}
            </button>

            {showSuccess && (
              <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 text-sm text-center">
                Adăugat în coș cu succes!
              </div>
            )}

            <div className="pt-6 border-t border-gray-100 space-y-3 text-sm text-gray-600">
              <p className="leading-relaxed">
                Transport gratuit pentru comenzi peste 600 RON
              </p>
              <p className="leading-relaxed">
                Retururi gratuite în 30 de zile
              </p>
              <p className="leading-relaxed">
                Materiale sustenabile și de calitate
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
