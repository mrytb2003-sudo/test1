import { X, Minus, Plus, Trash2 } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Cart({ isOpen, onClose }: CartProps) {
  const { items, updateQuantity, removeItem, total, itemCount } = useCart();

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity"
        onClick={onClose}
      ></div>

      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-2xl flex flex-col">
        <div className="border-b border-gray-100 px-6 py-4 flex justify-between items-center">
          <h2 className="text-lg font-light tracking-wide">
            Coșul Tău ({itemCount})
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          {items.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-6">Coșul tău este gol</p>
              <button
                onClick={onClose}
                className="bg-black text-white px-8 py-3 text-sm tracking-wider hover:bg-gray-800 transition-colors"
              >
                CONTINUĂ CUMPĂRĂTURILE
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {items.map(item => (
                <div key={`${item.product.id}-${item.size}-${item.color}`} className="flex gap-4">
                  <div className="w-24 h-32 bg-gray-100 flex-shrink-0">
                    <img
                      src={item.product.image_url}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 flex flex-col">
                    <div className="flex justify-between">
                      <div>
                        <h3 className="font-light text-sm mb-1">{item.product.name}</h3>
                        <p className="text-sm text-gray-600">{item.product.price.toFixed(2)} RON</p>
                        {item.size && (
                          <p className="text-xs text-gray-500 mt-1">Mărime: {item.size}</p>
                        )}
                        {item.color && (
                          <p className="text-xs text-gray-500">Culoare: {item.color}</p>
                        )}
                      </div>
                      <button
                        onClick={() => removeItem(item.product.id)}
                        className="p-1 hover:bg-gray-50 rounded h-fit"
                      >
                        <Trash2 className="w-4 h-4 text-gray-400" />
                      </button>
                    </div>

                    <div className="flex items-center gap-3 mt-3">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="p-1 hover:bg-gray-100 rounded"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="text-sm w-8 text-center">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="p-1 hover:bg-gray-100 rounded"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t border-gray-100 px-6 py-6 space-y-4">
            <div className="flex justify-between text-lg">
              <span className="font-light">Total</span>
              <span className="font-normal">{total.toFixed(2)} RON</span>
            </div>

            <button className="w-full bg-black text-white py-4 text-sm tracking-wider hover:bg-gray-800 transition-colors">
              FINALIZEAZĂ COMANDA
            </button>

            <button
              onClick={onClose}
              className="w-full text-center text-sm tracking-wide text-gray-600 hover:text-black transition-colors"
            >
              Continuă Cumpărăturile
            </button>
          </div>
        )}
      </div>
    </>
  );
}
