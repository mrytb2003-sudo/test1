import { Link } from 'react-router-dom';
import { getImageUrl } from '../utils/imageUtils';

export function Hero() {
  const scrollToProducts = () => {
    const productsSection = document.querySelector('[data-products-section]');
    productsSection?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url('${getImageUrl('/COPERTA.png')}')` }}
      ></div>

      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/50"></div>

      <button
        onClick={scrollToProducts}
        className="absolute top-[10%] left-[5%] md:top-[12%] md:left-[8%] z-20 w-32 h-12 md:w-40 md:h-16 cursor-pointer hover:opacity-80 transition-opacity duration-300"
        aria-label="Navighează la produse"
      ></button>

      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-light tracking-tight mb-8 leading-[1.15] text-white drop-shadow-lg" style={{ textShadow: '0 2px 10px rgba(0,0,0,0.5)' }}>
          Simplu. Atemporal.<br />
          <span className="italic">Eleganță fără efort.</span>
        </h1>

        <p className="text-lg md:text-xl text-white/95 mb-12 font-light leading-relaxed max-w-2xl mx-auto tracking-wide" style={{ textShadow: '0 2px 8px rgba(0,0,0,0.5)' }}>
          Modă selectată pentru femeia modernă.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link
            to="/categorie/noutati"
            className="bg-white text-black px-12 py-4 text-sm tracking-[0.2em] hover:bg-white/90 transition-all duration-300 font-light"
          >
            Vezi colecția
          </Link>
          <Link
            to="/categorie/rochii"
            className="border-2 border-white text-white px-12 py-4 text-sm tracking-[0.2em] hover:bg-white hover:text-black transition-all duration-300 font-light"
          >
            Vezi catalogul
          </Link>
        </div>
      </div>
    </section>
  );
}
