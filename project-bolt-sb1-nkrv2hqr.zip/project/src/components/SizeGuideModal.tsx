import { X } from 'lucide-react';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SizeGuideModal({ isOpen, onClose }: SizeGuideModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      ></div>

      <div className="relative bg-white rounded-sm shadow-2xl max-w-2xl w-full p-8 md:p-12">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          aria-label="Închide"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-2xl md:text-3xl font-light tracking-wide mb-8 text-center">
          Ghid de Mărimi
        </h2>

        <div className="space-y-6">
          <div className="border-b border-gray-200 pb-6">
            <h3 className="text-sm tracking-wider text-gray-500 mb-4 uppercase">
              Mărimi Standard
            </h3>

            <div className="space-y-4">
              <div className="flex items-start">
                <span className="font-medium text-lg w-8">S:</span>
                <div className="flex-1 text-gray-700 leading-relaxed">
                  Bust 84-88 cm | Talie 64-68 cm | Șolduri 90-94 cm
                </div>
              </div>

              <div className="flex items-start">
                <span className="font-medium text-lg w-8">M:</span>
                <div className="flex-1 text-gray-700 leading-relaxed">
                  Bust 89-93 cm | Talie 69-73 cm | Șolduri 95-99 cm
                </div>
              </div>

              <div className="flex items-start">
                <span className="font-medium text-lg w-8">L:</span>
                <div className="flex-1 text-gray-700 leading-relaxed">
                  Bust 94-98 cm | Talie 74-78 cm | Șolduri 100-104 cm
                </div>
              </div>
            </div>
          </div>

          <p className="text-sm text-gray-500 text-center leading-relaxed">
            Pentru întrebări suplimentare, vă rugăm să ne contactați.
          </p>
        </div>
      </div>
    </div>
  );
}
