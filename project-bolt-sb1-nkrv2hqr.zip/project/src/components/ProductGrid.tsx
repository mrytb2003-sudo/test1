import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Product } from '../types/database';
import { ProductCard } from './ProductCard';

interface ProductGridProps {
  onProductClick: (product: Product) => void;
}

export function ProductGrid({ onProductClick }: ProductGridProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'featured'>('all');

  useEffect(() => {
    fetchProducts();
  }, [filter]);

  async function fetchProducts() {
    setLoading(true);
    try {
      let query = supabase.from('products').select('*').order('created_at', { ascending: false });

      if (filter === 'featured') {
        query = query.eq('featured', true);
      }

      const { data, error } = await query;

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-gray-300 border-t-black rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <section data-products-section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div id="noutati" className="scroll-mt-32"></div>
      <div className="flex items-center justify-between mb-12">
        <div>
          <h2 className="text-3xl font-light tracking-tight mb-2">Colecția Noastră</h2>
          <p className="text-gray-600 text-sm">
            {products.length} {products.length === 1 ? 'piesă' : 'piese'}
          </p>
        </div>
        <div className="flex space-x-4">
          <button
            onClick={() => setFilter('all')}
            className={`text-sm tracking-wide pb-1 transition-colors ${
              filter === 'all'
                ? 'border-b-2 border-black text-black'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            Toate
          </button>
          <button
            onClick={() => setFilter('featured')}
            className={`text-sm tracking-wide pb-1 transition-colors ${
              filter === 'featured'
                ? 'border-b-2 border-black text-black'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            Recomandate
          </button>
        </div>
      </div>

      {products.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-gray-500">Nu au fost găsite produse</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-12">
          {products.map(product => (
            <ProductCard key={product.id} product={product} onClick={() => onProductClick(product)} />
          ))}
        </div>
      )}
    </section>
  );
}
