/*
  # Create Product Images Storage

  1. Storage Setup
    - Create `product-images` storage bucket for product photos
    - Enable public access for product images
  
  2. Security
    - Allow public read access to product images
    - Restrict upload/delete to authenticated users only (for future admin panel)
  
  3. Notes
    - Images will be publicly accessible via Supabase CDN
    - Supports all common image formats (jpg, png, webp, etc.)
*/

-- Create storage bucket for product images
INSERT INTO storage.buckets (id, name, public)
VALUES ('product-images', 'product-images', true)
ON CONFLICT (id) DO NOTHING;

-- Allow public read access to product images
CREATE POLICY "Public can view product images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'product-images');

-- Allow authenticated users to upload images (for future admin functionality)
CREATE POLICY "Authenticated users can upload product images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'product-images');

-- Allow authenticated users to update images
CREATE POLICY "Authenticated users can update product images"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'product-images');

-- Allow authenticated users to delete images
CREATE POLICY "Authenticated users can delete product images"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'product-images');