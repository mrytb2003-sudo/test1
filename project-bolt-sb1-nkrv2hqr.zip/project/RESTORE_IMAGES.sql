-- Run this SQL in your Supabase SQL Editor to restore original product images
-- https://djdkujwxkwchboxpqbgz.supabase.co

-- Restore Set products
UPDATE products SET image_url = '/1.png', images = '["/2.png", "/3.png"]'::jsonb WHERE id = 'd696dcd9-0b43-40f4-96bb-42d9008ac37c';
UPDATE products SET image_url = '/7.png', images = '["/8.png", "/9.png"]'::jsonb WHERE id = '45950842-5162-4f9e-9357-a59630ed75ff';

-- Restore Fusta cu volane products with new gray image as hover
UPDATE products SET image_url = '/13.png', images = '["/13-gray.png"]'::jsonb WHERE id = 'bffd52ef-5f75-4051-b7a5-e049bc6d87f4';
UPDATE products SET image_url = '/14.png', images = '[]'::jsonb WHERE id = '4f9c594b-c2f6-41ab-9649-1344acdb9f27';
UPDATE products SET image_url = '/15.png', images = '[]'::jsonb WHERE id = '13beeab8-6568-4d97-8b4f-731e99fcc697';

-- Update Fusta gogosar products with NEW uploaded images and correct prices
UPDATE products SET image_url = '/20-blue.png', images = '[]'::jsonb, price = 250 WHERE id = '095fb861-a243-4624-ad18-e5f3a0696ab7';
UPDATE products SET image_url = '/21-cream.png', images = '[]'::jsonb, price = 350 WHERE id = '985862d4-465f-46b3-9506-9d8ea8d59639';
UPDATE products SET image_url = '/22-pink.png', images = '[]'::jsonb, price = 250 WHERE id = 'a7b1b886-6704-4a42-9b44-ca7eade118cf';

-- Verify the updates
SELECT id, name, price, image_url, images FROM products ORDER BY name, price;
